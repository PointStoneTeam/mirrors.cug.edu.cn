rsync rsync://dl.fedoraproject.org/fedora-enchilada/linux/ /mirrorsxgxy/fedora/ -aHvh --delete --delete-delay --stats --safe-links --timeout=120 --contimeout=120 --delay-updates
rsync rsync://ftp.cn.debian.org/debian/ /mirrorsxgxy/debian/ -aHvh --delete --delete-delay --stats --safe-links --timeout=120 --contimeout=120 --delay-updates
rsync rsync://archive.ubuntu.com/ubuntu/ /mirrorswlzx/ubuntu/ -aHvh --delete --delete-delay --stats --safe-links --timeout=120 --contimeout=120 --delay-updates
